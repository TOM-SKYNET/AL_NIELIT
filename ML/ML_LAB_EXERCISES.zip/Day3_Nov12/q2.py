"""
	2. Develop an ML model to predict the home price from interest rate.(loan.csv file)
"""

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from  sklearn import metrics
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

data=pd.read_csv("loan.csv")
print (data.head())
data=data.as_matrix()
print(data)
X=data[:,[2]]
y=data[:,-2]
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2)

lr=LinearRegression()
lr.fit(X_train,y_train)
p=lr.predict(X_test)

print(metrics.mean_absolute_error(y_test,p))
print(metrics.mean_squared_error(y_test,p))
print(np.sqrt(metrics.mean_squared_error(y_test,p)))

